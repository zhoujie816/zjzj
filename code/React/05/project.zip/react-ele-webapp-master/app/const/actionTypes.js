'use strict';
//登录状态
export const LOGIN_STATE = 'LOGIN_STATE'
//登入成功
export const LOG_SUCCESS = 'LOG_SUCCESS'
//正在登录
export const LOG_ING = 'LOG_ING'
//注销登录
export const LOG_OUT = 'LOG_OUT'