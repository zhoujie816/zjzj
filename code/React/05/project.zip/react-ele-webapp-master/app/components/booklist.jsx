import React from 'react'
import { render } from 'react-dom'

const Booklist = React.createClass({
	render(){
		return(
			<div>Booklist</div>
		)
	}
})

export default Booklist