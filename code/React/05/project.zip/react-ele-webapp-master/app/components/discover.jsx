import React from 'react'

const Discover = React.createClass({
	render(){
		return(
			<div style={{height:1000}}>Discover</div>
		)
	}
})

export default Discover